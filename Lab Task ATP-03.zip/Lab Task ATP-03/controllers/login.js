var express = require('express');
var userModel = require.main.require('./models/user-model');
var router = express.Router();

router.get('*', function(req, res, next){
	if(req.cookies['username'] != null){
		res.redirect('/home');
	}else{
		next();
	}
});

router.get('/', function(req, res){
	res.render('Login/index');
});


router.post('/', function(req, res){

var user ={
	username: req.body.uname,
		password: req.body.password
 	};
	if(req.body.user=='admin')
	{
		userModel.validateadmin(user, function(status){
			if(status){
			   res.cookie('username', req.body.uname);
			  res.redirect('/home');
		  }else{
			   res.redirect('/login');
		  }
	   });
	}
	else if(req.body.user=='employee'){
		userModel.validateemployee(user, function(status){
			if(status){
			   res.cookie('username', req.body.uname);
			  res.redirect('/home/employee');
		  }else{
			   res.redirect('/login');
		  }
	   });
	}
	else
	{
		res.send('select admin or employee');
	}
	
 });

module.exports = router;