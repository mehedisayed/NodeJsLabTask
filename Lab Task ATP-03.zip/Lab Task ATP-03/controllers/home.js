var express = require('express');
var router = express.Router();
var userModel = require.main.require('./models/user-model');


router.get('*', function(req, res, next){
	if(req.cookies['username'] == null){
		res.redirect('/login');
	}else{
		next();
	}
});

router.get('/', function(req, res){
	userModel.getByUname(req.cookies['username'], function(result){
		res.render('home/indexadmin', {user: result});
	});
});

router.get('/employee', function(req, res){
	userModel.getByEUname(req.cookies['username'], function(result){
		res.render('home/indexemployee', {user: result});
	});
});

 router.get('/view_employees', function(req, res){
	
	userModel.getAll(function(results){
 		if(results.length > 0){
 			res.render('home/view_employees', {userlist: results});
		}else{
			res.redirect('/home');
		}
	});
});

router.get('/edit/:id', function(req, res){
	userModel.getByEmpId(req.params.id, function(result){
		res.render('home/edit', {user: result});
	});
});



module.exports = router;